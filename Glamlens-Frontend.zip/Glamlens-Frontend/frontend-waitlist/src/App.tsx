import React from 'react'
import { Navigation } from './Navigation'
import { Hero } from './Hero'
import { Categories } from './Categories'
import { ProductsGrid } from './ProductsGrid'
import { WhyGlamLens } from './WhyGlamLens'
import { Footer } from './Footer'

const App: React.FC = () => {
  return (
    <div className="w-full bg-white">
      <Navigation />
      <main className="mx-auto">
        <Hero />
        <Categories />
        <ProductsGrid />
        <WhyGlamLens />
      </main>
      <Footer />
    </div>
  )
}

export default App
