import React from 'react'

interface CategoryProps {
  emoji: string
  label: string
  bgGradient: string
}

const Category: React.FC<CategoryProps> = ({ emoji, label, bgGradient }) => (
  <div className="flex flex-col items-center gap-2.5 cursor-pointer">
    <div className={`w-28 h-28 md:w-20 md:h-20 rounded-full border-2 border-gray-300 overflow-hidden flex items-center justify-center text-5xl ${bgGradient} hover:border-purple-main hover:scale-105 transition-all`}>
      {emoji}
    </div>
    <span className="text-sm md:text-xs font-semibold text-dark-text text-center">{label}</span>
  </div>
)

export const Categories: React.FC = () => {
  const categories: CategoryProps[] = [
    { emoji: '👩‍🦱', label: 'Wigs & Hair', bgGradient: 'bg-gradient-to-br from-purple-100 to-purple-200' },
    { emoji: '💄', label: 'Makeup & Beauty', bgGradient: 'bg-gradient-to-br from-pink-100 to-pink-200' },
    { emoji: '👗', label: "Women's Clothing", bgGradient: 'bg-gradient-to-br from-yellow-100 to-yellow-200' },
    { emoji: '🕴️', label: "Men's Fashion", bgGradient: 'bg-gradient-to-br from-blue-100 to-blue-200' },
    { emoji: '👒', label: 'Accessories', bgGradient: 'bg-gradient-to-br from-emerald-100 to-emerald-200' },
  ]

  return (
    <section className="py-12 md:py-7 px-10 md:px-4 bg-white max-w-6xl mx-auto">
      <h2 className="font-inter text-2xl font-black text-dark-text text-center mb-8">Popular Categories</h2>
      <div className="flex justify-center gap-8 md:gap-4 flex-wrap">
        {categories.map((cat) => (
          <Category key={cat.label} {...cat} />
        ))}
      </div>
    </section>
  )
}
