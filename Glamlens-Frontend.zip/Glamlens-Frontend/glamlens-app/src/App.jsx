import React from 'react'

interface ReactNode {
  [key: string]: unknown
}

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="font-inter text-4xl font-black text-center text-dark-text mb-4">
          GlamLens App
        </h1>
        <p className="font-inter text-center text-gray-600 mb-8">
          Welcome to the GlamLens application. Built with TypeScript and Tailwind CSS for scalability and maintainability.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {['Feature 1', 'Feature 2', 'Feature 3'].map((feature, i) => (
            <div key={i} className="p-6 border border-border-light rounded-lg hover:shadow-lg transition-all">
              <h2 className="font-inter font-bold text-lg text-dark-text mb-2">{feature}</h2>
              <p className="text-sm text-gray-600">
                Modern, scalable architecture with full TypeScript support and Tailwind styling.
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default App
